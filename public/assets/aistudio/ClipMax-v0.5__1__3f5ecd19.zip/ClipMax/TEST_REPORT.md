# ClipMax v0.5.1 — Card Actions Fix

## Change

Replaced the long-press menu that relied on a dialog created by the IME service with inline **Edit**, **Pin/Unpin**, and **Delete** buttons rendered below the selected card. Users can reveal these actions by long-pressing the card or tapping its visible **More** button. The card body also has its own long-press handler. Edit opens the selected saved item in ClipMax's existing editor, where **Choose a typing keyboard** opens Android's IME picker; pin/unpin persists metadata, and delete removes the item and its expiry entry.

## Verification

The final `./gradlew --no-daemon testDebugUnitTest assembleDebug --stacktrace` run completed with **BUILD SUCCESSFUL**. All **17 JVM tests passed** (0 failures, 0 errors). The APK is `delivery/ClipMax-v0.5.1-debug.apk`, package `com.clipmax.app`, version 0.5.1/code 10, min SDK 26 and target SDK 35. `apksigner verify` and `zipalign -c -v 4` passed. SHA-256: `75a71602e2b5074af0d78f9a919b8b9425d957fc4ca7f63d73439aeb085dc3b4`.

There is no connected Android device or emulator in this environment, so the inline controls, touch/long-press delivery, and editor handoff still require phone testing. The APK is debug-signed, not production/Play Store signed.
