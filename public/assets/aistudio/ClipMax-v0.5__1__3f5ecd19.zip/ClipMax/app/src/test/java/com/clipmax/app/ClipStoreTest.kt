package com.clipmax.app

import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import java.io.ByteArrayInputStream
import java.io.ByteArrayOutputStream
import java.io.Reader
import java.nio.file.Files

class ClipStoreTest {
    private lateinit var root: java.io.File
    private lateinit var store: ClipStore

    @Before
    fun setUp() {
        root = Files.createTempDirectory("clipmax-test-").toFile()
        store = ClipStore(root)
    }

    @After
    fun tearDown() {
        root.deleteRecursively()
    }

    @Test
    fun savesAndReopensRequiredLargeTextSizesExactly() {
        listOf(20_000, 100_000, 500_000, 1_000_000).forEach { count ->
            val content = "x".repeat(count - 1) + "😀"
            val item = store.save(null, "size-$count", content)
            assertEquals(count, item.characterCount)
            assertEquals((count - 1L) + 4L, item.sizeBytes)
            assertEquals(content, store.readContent(item))
            val reopenedStore = ClipStore(root)
            assertEquals(content, reopenedStore.readContent(reopenedStore.getItem(item.id)!!))
        }
    }

    @Test
    fun savedItemStreamsThroughSmallUnicodeSafeChunks() {
        val content = "chunk😀".repeat(50_000)
        val item = store.save(null, "stream source", content)
        val reconstructed = StringBuilder(content.length)
        var chunkCount = 0
        val completed = store.openTextReader(item.id).use { reader ->
            TextChunker.forEachChunk(reader) { chunk ->
                assertTrue(chunk.length <= TextChunker.DEFAULT_CHUNK_CHARS)
                assertFalse(Character.isHighSurrogate(chunk.last()))
                assertFalse(Character.isLowSurrogate(chunk.first()))
                reconstructed.append(chunk)
                chunkCount++
                true
            }
        }
        assertTrue(completed)
        assertTrue(chunkCount > 5)
        assertEquals(content, reconstructed.toString())
    }

    @Test
    fun selectedTextCanBeStreamedDirectlyIntoPrivateStorage() {
        val selected: CharSequence = "Selected 😀 line\n".repeat(20_000)
        val item = store.saveFromReader(null, "Captured selection", TextChunker.reader(selected))
        assertEquals("Captured selection", item.title)
        assertEquals(Character.codePointCount(selected, 0, selected.length), item.characterCount)
        assertEquals(selected.toString().toByteArray(Charsets.UTF_8).size.toLong(), item.sizeBytes)
        assertEquals(selected.toString(), store.readContent(item))
    }

    @Test
    fun capturedTextIsSavedAsSeparateFiftyThousandUnitCardsWithSerials() {
        val text = ("a".repeat(49_999) + "😀" + "b".repeat(8_000)).repeat(3)
        val cards = mutableListOf<ClipItem>()
        val count = ClipCaptureWriter.saveToCards(store, text, "Copy", "12:34:56", onSaved = cards::add)
        assertEquals(4, count)
        assertEquals(count, cards.size)
        assertEquals((1..count).map { "Copy · Chunk ${it.toString().padStart(3, '0')}/${count.toString().padStart(3, '0')} · 12:34:56" }, cards.map { it.title })
        assertEquals(cards[1].id, store.search("Chunk 002/004").single().id)
        assertTrue(cards.all { it.characterCount <= 50_000 })
        cards.dropLast(1).forEach { assertFalse(Character.isHighSurrogate(store.readContent(it).last())) }
        cards.drop(1).forEach { assertFalse(Character.isLowSurrogate(store.readContent(it).first())) }
        assertEquals(text, cards.joinToString("") { store.readContent(it) })
    }

    @Test
    fun overLimitReaderDoesNotCreateAnItemOrReplaceExistingContent() {
        val previous = store.save(null, "Keep", "original")
        val source = object : Reader() {
            private var remaining = ClipStore.MAX_ITEM_BYTES.toInt() + 1
            override fun read(buffer: CharArray, offset: Int, length: Int): Int {
                if (remaining == 0) return -1
                val count = minOf(length, remaining)
                java.util.Arrays.fill(buffer, offset, offset + count, 'x')
                remaining -= count
                return count
            }
            override fun close() = Unit
        }
        val error = runCatching { store.saveFromReader(null, "Too large", source) }.exceptionOrNull()
        assertTrue(error is IllegalArgumentException)
        assertEquals("original", store.readContent(store.getItem(previous.id)!!))
        assertEquals(1, store.listItems().size)
    }

    @Test
    fun unicodeMultilineVeryLongLineAndSearchSurviveRoundTrip() {
        val content = "First line\n日本語 café 🧪\n" + "z".repeat(50_000) + " NeedleAcrossLongLine\nlast"
        val item = store.save(null, "Unicode sample", content)
        assertEquals(content, store.readContent(item))
        assertEquals(item.id, store.search("日本語").single().id)
        assertEquals(item.id, store.search("needleacrosslongline").single().id)
        assertEquals(item.id, store.search("Unicode").single().id)
    }

    @Test
    fun editsKeepStableIdAndPreserveCreatedDate() {
        val first = store.save(null, "Draft", "initial")
        Thread.sleep(2)
        val updated = store.save(first.id, "Renamed title", "updated\ntext", pinned = true)
        assertEquals(first.id, updated.id)
        assertEquals(first.createdAt, updated.createdAt)
        assertTrue(updated.pinned)
        assertEquals("updated\ntext", store.readContent(store.getItem(first.id)!!))
        assertEquals("Renamed title", store.getItem(first.id)!!.title)
    }

    @Test
    fun pinRenameDuplicateDeleteAndDraftArePersisted() {
        val original = store.save(null, "Example", "one two")
        store.setPinned(original.id, true)
        store.rename(original.id, "Changed")
        val copy = store.duplicate(original.id)
        assertNotEquals(original.id, copy.id)
        assertEquals("one two", store.readContent(copy))
        store.saveDraft(original.id, "Changed", "unsaved text")
        assertEquals("unsaved text", store.loadDraft()!!.content)
        store.clearDraft()
        assertNull(store.loadDraft())
        assertTrue(store.delete(original.id))
        assertNull(store.getItem(original.id))
        assertEquals(1, store.listItems().size)
    }

    @Test
    fun libraryCanContainMoreThanFifteenCards() {
        repeat(25) { index -> store.save(null, "Card ${index + 1}", "text-${index + 1}") }
        assertEquals(25, store.listItems().size)
    }

    @Test
    fun emptyContentAndRepeatedSavesStayPersistent() {
        val empty = store.save(null, "Empty", "")
        assertEquals(0, empty.characterCount)
        assertEquals(0L, empty.sizeBytes)
        assertEquals("", store.readContent(empty))
        val first = store.save(empty.id, "Repeated", "first")
        val second = store.save(first.id, "Repeated", "second save\nwith lines")
        assertEquals(empty.id, second.id)
        assertEquals("second save\nwith lines", store.readContent(store.getItem(empty.id)!!))
    }

    @Test
    fun textImportAndLibraryBackupRestoreRoundTrip() {
        val sourceText = "Imported\ntext — 👋"
        val imported = store.importText(ByteArrayInputStream(sourceText.toByteArray(Charsets.UTF_8)), "from-file")
        assertEquals("from-file", imported.title)
        val exportedText = ByteArrayOutputStream()
        store.writeTextTo(imported.id, exportedText)
        assertEquals(sourceText, String(exportedText.toByteArray(), Charsets.UTF_8))
        val second = store.save(null, "second", "more content")
        val backup = ByteArrayOutputStream()
        store.backup(backup)

        val restoredRoot = Files.createTempDirectory("clipmax-restore-").toFile()
        try {
            val restoredStore = ClipStore(restoredRoot)
            assertEquals(2, restoredStore.restore(ByteArrayInputStream(backup.toByteArray())))
            assertEquals(2, restoredStore.listItems().size)
            assertEquals(sourceText, restoredStore.readContent(restoredStore.listItems().first { it.title == "from-file" }))
            assertEquals("more content", restoredStore.readContent(restoredStore.listItems().first { it.title == "second" }))
            val merged = restoredStore.restore(ByteArrayInputStream(backup.toByteArray()))
            assertEquals(2, merged)
            assertEquals(4, restoredStore.listItems().size)
        } finally {
            restoredRoot.deleteRecursively()
        }
        assertEquals("more content", store.readContent(store.getItem(second.id)!!))
    }

    @Test
    fun overLimitSaveFailsWithoutReplacingExistingItem() {
        val item = store.save(null, "safe", "original")
        val tooLarge = "x".repeat((ClipStore.MAX_ITEM_BYTES + 1).toInt())
        val failure = runCatching { store.save(item.id, "changed", tooLarge) }.exceptionOrNull()
        assertTrue(failure is IllegalArgumentException)
        assertEquals("original", store.readContent(store.getItem(item.id)!!))
        assertEquals("safe", store.getItem(item.id)!!.title)
    }
}
