package com.clipmax.app

import org.junit.Assert.*
import org.junit.Test
import java.io.StringReader

class TextChunkerTest {
    @Test
    fun defaultChunksAreAtMostFiftyThousandUtf16Units() {
        val text = ("x".repeat(49_999) + "😀" + "y".repeat(8_000)).repeat(3)
        val chunks = mutableListOf<String>()
        assertTrue(TextChunker.forEachChunk(StringReader(text)) { chunks += it; true })
        assertTrue(chunks.size > 3)
        assertEquals(chunks.size, TextChunker.chunkCount(text))
        assertTrue(chunks.all { it.length <= 50_000 })
        chunks.dropLast(1).forEach { assertFalse(Character.isHighSurrogate(it.last())) }
        chunks.drop(1).forEach { assertFalse(Character.isLowSurrogate(it.first())) }
        assertEquals(text, chunks.joinToString(""))
    }

    @Test
    fun emptyTextHasNoCardsAndExactBoundaryHasOneCard() {
        assertEquals(0, TextChunker.chunkCount(""))
        assertEquals(1, TextChunker.chunkCount("x".repeat(50_000)))
        assertEquals(2, TextChunker.chunkCount("x".repeat(49_999) + "😀"))
    }

    @Test
    fun selectedTextCharSequenceReaderStreamsExactUnicode() {
        val text: CharSequence = StringBuilder("selected 👋\n".repeat(3_000))
        val chunks = mutableListOf<String>()
        assertTrue(TextChunker.forEachChunk(TextChunker.reader(text), chunkChars = 97) { chunks += it; true })
        assertEquals(text.toString(), chunks.joinToString(""))
        assertTrue(chunks.all { it.length <= 97 })
    }

    @Test
    fun chunksPreserveExactUnicodeTextAndDoNotSplitSurrogatePairs() {
        val text = "a".repeat(7) + "😀" + "界".repeat(9) + "👩‍💻" + "z".repeat(5)
        val chunks = mutableListOf<String>()
        assertTrue(TextChunker.forEachChunk(StringReader(text), chunkChars = 4) { chunks += it; true })
        assertEquals(text, chunks.joinToString(""))
        assertTrue(chunks.all { it.length <= 5 }) // at most one carried high surrogate
        chunks.dropLast(1).forEach { chunk -> assertFalse(Character.isHighSurrogate(chunk.last())) }
        chunks.drop(1).forEach { chunk -> assertFalse(Character.isLowSurrogate(chunk.first())) }
    }

    @Test
    fun emptyAndCancelledStreamsHaveClearResults() {
        val chunks = mutableListOf<String>()
        assertTrue(TextChunker.forEachChunk(StringReader(""), chunkChars = 8) { chunks += it; true })
        assertTrue(chunks.isEmpty())
        assertFalse(TextChunker.forEachChunk(StringReader("first second"), chunkChars = 5) { chunks += it; false })
        assertEquals(1, chunks.size)
    }
}
