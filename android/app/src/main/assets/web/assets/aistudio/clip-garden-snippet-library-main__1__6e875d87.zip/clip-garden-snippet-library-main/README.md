# ClipMax — visual design prototype

This is a **web prototype** of the ClipMax v0.5.1 visual design (Library, Details, Editor, Settings, Keyboard panel).
It uses in-memory sample data only. Clipboard, document picker (TXT import/export), share sheet, ZIP backup/restore
and the keyboard (IME) are **simulated** and clearly labelled as such.

The design will later be translated into native, programmatically created Android Views. The existing Kotlin
`ClipStore` and `ClipMaxImeService` remain authoritative for storage, clipboard and keyboard behaviour; nothing in this
prototype replaces or claims to implement them.

Design tokens live in `src/styles.css` (light + dark, neutral charcoal surfaces, muted mint accent).
