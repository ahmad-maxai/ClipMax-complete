import { useState } from "react";
import { ArrowLeft, Copy, CopyPlus, Download, Pencil, Pin, PinOff, Share2, Trash2, Type } from "lucide-react";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Btn, IconBtn, TopBar } from "./primitives";
import { Confirm } from "./Confirm";
import { bytesOf, formatBytes, fullDate, useClips } from "@/lib/clipstore";
import type { Nav } from "./types";

export function Details({ id, nav }: { id: string; nav: Nav }) {
  const { get, update, duplicate, remove } = useClips();
  const clip = get(id);
  const [renaming, setRenaming] = useState(false);
  const [name, setName] = useState("");
  const [confirmDelete, setConfirmDelete] = useState(false);

  if (!clip) {
    return (
      <div className="p-6 text-center text-sm text-muted-foreground">
        This item no longer exists. <button className="underline" onClick={() => nav({ name: "library" })}>Back to library</button>
      </div>
    );
  }

  const lines = clip.content.split("\n").length;
  const words = clip.content.trim() ? clip.content.trim().split(/\s+/).length : 0;

  const actions = [
    { label: "Edit", icon: Pencil, run: () => nav({ name: "editor", id }) },
    { label: clip.pinned ? "Unpin" : "Pin", icon: clip.pinned ? PinOff : Pin, run: () => { update(id, { pinned: !clip.pinned }); toast(clip.pinned ? "Unpinned" : "Pinned to top"); } },
    { label: "Rename", icon: Type, run: () => { setName(clip.title); setRenaming(true); } },
    { label: "Duplicate", icon: CopyPlus, run: () => { const d = duplicate(id); toast.success("Duplicated", { action: d ? { label: "Open", onClick: () => nav({ name: "details", id: d.id }) } : undefined }); } },
    { label: "Export", icon: Download, run: () => toast(`Export “${clip.title}.txt”`, { description: "Simulated — the app opens Android's document picker." }) },
    { label: "Share", icon: Share2, run: () => toast("Share sheet", { description: "Simulated — the app opens Android's share sheet." }) },
  ];

  return (
    <div className="flex min-h-full flex-col">
      <TopBar
        left={<IconBtn label="Back" onClick={() => nav({ name: "library" })}><ArrowLeft className="h-5 w-5" /></IconBtn>}
        title={<span className="text-[15px] font-semibold">Details</span>}
        right={<IconBtn label="Delete" className="text-destructive" onClick={() => setConfirmDelete(true)}><Trash2 className="h-5 w-5" /></IconBtn>}
      />

      <div className="flex-1 space-y-3 px-4 pb-24 pt-4">
        <div>
          <div className="flex items-start gap-2">
            <h1 className="flex-1 text-xl font-semibold leading-tight tracking-tight">{clip.title}</h1>
            {clip.pinned && <Pin className="mt-1 h-4 w-4 text-mint" aria-label="Pinned" />}
          </div>
          <dl className="mt-2 grid grid-cols-2 gap-x-4 gap-y-1 text-xs">
            <Meta k="Modified" v={fullDate(clip.modifiedAt)} />
            <Meta k="Created" v={fullDate(clip.createdAt)} />
            <Meta k="Size" v={`${clip.content.length.toLocaleString()} chars · ${formatBytes(bytesOf(clip.content))}`} />
            <Meta k="Text" v={`${words.toLocaleString()} words · ${lines} lines`} />
          </dl>
        </div>

        <div className="max-h-[42vh] overflow-y-auto rounded-xl border border-border bg-surface px-4 py-3">
          <p className="whitespace-pre-wrap break-words text-[14px] leading-relaxed">{clip.content || <span className="text-muted-foreground">Empty</span>}</p>
        </div>

        <div className="grid grid-cols-3 gap-2">
          {actions.map((a) => (
            <button key={a.label} type="button" onClick={a.run} className="flex h-16 flex-col items-center justify-center gap-1 rounded-xl border border-border bg-surface text-[12px] font-medium hover:bg-surface-2 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring">
              <a.icon className="h-[18px] w-[18px]" aria-hidden />
              {a.label}
            </button>
          ))}
        </div>
      </div>

      <div className="sticky bottom-0 flex gap-2 border-t border-border bg-background px-4 py-3">
        <Btn variant="dangerOutline" onClick={() => setConfirmDelete(true)}><Trash2 className="h-4 w-4" />Delete</Btn>
        <Btn
          variant="primary"
          className="flex-1"
          onClick={() => {
            navigator.clipboard?.writeText(clip.content).catch(() => {});
            toast.success("Copied to clipboard", { description: "Prototype uses the browser clipboard; the app uses Android ClipboardManager." });
          }}
        >
          <Copy className="h-4 w-4" />Copy
        </Btn>
      </div>

      <Dialog open={renaming} onOpenChange={setRenaming}>
        <DialogContent className="max-w-[340px] rounded-xl">
          <DialogHeader><DialogTitle>Rename item</DialogTitle></DialogHeader>
          <form
            onSubmit={(e) => {
              e.preventDefault();
              if (!name.trim()) return;
              update(id, { title: name.trim() });
              setRenaming(false);
              toast("Renamed");
            }}
          >
            <label className="text-xs font-medium text-muted-foreground" htmlFor="rename">Title</label>
            <input id="rename" autoFocus value={name} onChange={(e) => setName(e.target.value)} className="mt-1 h-11 w-full rounded-lg border border-input bg-surface px-3 text-sm outline-none focus:border-mint focus:ring-2 focus:ring-ring/30" />
            <DialogFooter className="mt-4 flex-row justify-end gap-2">
              <Btn variant="ghost" size="sm" onClick={() => setRenaming(false)}>Cancel</Btn>
              <Btn type="submit" variant="primary" size="sm" disabled={!name.trim()}>Rename</Btn>
            </DialogFooter>
          </form>
        </DialogContent>
      </Dialog>

      <Confirm
        open={confirmDelete}
        onOpenChange={setConfirmDelete}
        title="Delete this item?"
        description={`“${clip.title}” will be permanently removed from this device.`}
        confirmLabel="Delete"
        onConfirm={() => { remove(id); nav({ name: "library" }); toast("Item deleted"); }}
      />
    </div>
  );
}

function Meta({ k, v }: { k: string; v: string }) {
  return (
    <div className="min-w-0">
      <dt className="text-muted-foreground">{k}</dt>
      <dd className="truncate font-medium">{v}</dd>
    </div>
  );
}
