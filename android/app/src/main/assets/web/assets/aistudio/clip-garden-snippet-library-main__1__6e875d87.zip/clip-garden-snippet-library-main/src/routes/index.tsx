import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Toaster } from "sonner";
import { ClipStoreProvider } from "@/lib/clipstore";
import { Library } from "@/components/clipmax/Library";
import { Details } from "@/components/clipmax/Details";
import { Editor } from "@/components/clipmax/Editor";
import { SettingsScreen } from "@/components/clipmax/SettingsScreen";
import { KeyboardPrototype } from "@/components/clipmax/KeyboardPrototype";
import type { Screen } from "@/components/clipmax/types";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "ClipMax — Android clipboard manager design prototype" },
      { name: "description", content: "Interactive visual prototype of ClipMax: library, details, editor, settings and keyboard panel." },
      { property: "og:title", content: "ClipMax — design prototype" },
      { property: "og:description", content: "Interactive visual prototype of the ClipMax Android clipboard manager." },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Index,
});

const TABS: { label: string; screen: Screen }[] = [
  { label: "Library", screen: { name: "library" } },
  { label: "Details", screen: { name: "details", id: "c3" } },
  { label: "Editor", screen: { name: "editor", id: "c2" } },
  { label: "Settings", screen: { name: "settings" } },
  { label: "Keyboard", screen: { name: "keyboard" } },
];

function Index() {
  const [screen, setScreen] = useState<Screen>({ name: "library" });
  const [dark, setDark] = useState(false);

  useEffect(() => {
    document.documentElement.classList.toggle("dark", dark);
  }, [dark]);

  const nav = (s: Screen) => {
    setScreen(s);
    document.getElementById("phone")?.scrollTo({ top: 0 });
  };

  return (
    <ClipStoreProvider>
      <div className="min-h-screen sm:flex sm:items-start sm:justify-center sm:gap-10 sm:py-8">
        <aside className="hidden max-w-xs pt-10 lg:block">
          <p className="text-[11px] font-semibold uppercase tracking-[0.1em] text-mint">Design prototype</p>
          <h1 className="mt-2 text-2xl font-semibold tracking-tight">ClipMax v0.5.1</h1>
          <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
            A web prototype of the visual design only. It will be translated into native Android Views; the existing Kotlin
            ClipStore and ClipMaxImeService remain authoritative. Clipboard, file picker, backup and keyboard actions are simulated
            with sample data.
          </p>
          <nav className="mt-6 flex flex-col gap-1" aria-label="Jump to screen">
            {TABS.map((t) => (
              <button key={t.label} onClick={() => nav(t.screen)} className={cn("h-10 rounded-lg px-3 text-left text-sm font-medium hover:bg-surface", screen.name === t.screen.name && "bg-surface text-mint-foreground")}>
                {t.label}
              </button>
            ))}
            <button onClick={() => setDark((d) => !d)} className="mt-2 h-10 rounded-lg border border-border px-3 text-left text-sm font-medium hover:bg-surface">
              {dark ? "Light theme" : "Dark theme"}
            </button>
          </nav>
        </aside>

        <div className="sm:w-[390px]">
          <div
            id="phone"
            className="relative h-[100dvh] overflow-y-auto bg-background sm:h-[820px] sm:rounded-[28px] sm:border sm:border-border sm:shadow-[0_30px_60px_-30px_oklch(0_0_0/0.35)]"
          >
            {screen.name === "library" && <Library nav={nav} dark={dark} toggleTheme={() => setDark((d) => !d)} />}
            {screen.name === "details" && <Details key={screen.id} id={screen.id} nav={nav} />}
            {screen.name === "editor" && <Editor key={screen.id ?? "new"} {...(screen.id === undefined ? {} : { id: screen.id })} nav={nav} />}
            {screen.name === "settings" && <SettingsScreen nav={nav} />}
            {screen.name === "keyboard" && <KeyboardPrototype nav={nav} />}
          </div>
          <p className="hidden px-2 pt-3 text-center text-[11px] text-muted-foreground sm:block lg:hidden">
            Web design prototype · native actions are simulated
          </p>
        </div>
      </div>
      <Toaster theme={dark ? "dark" : "light"} position="top-center" toastOptions={{ className: "font-sans" }} />
    </ClipStoreProvider>
  );
}
