import { useMemo, useState } from "react";
import { ArrowLeft, MoreHorizontal, Pencil, Pin, PinOff, Search, Trash2, X, CornerDownLeft, Delete } from "lucide-react";
import { toast } from "sonner";
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu";
import { Btn, IconBtn, TopBar } from "./primitives";
import { Confirm } from "./Confirm";
import { filterClips, sortClips, useClips, type Clip } from "@/lib/clipstore";
import { cn } from "@/lib/utils";
import type { Nav } from "./types";

export function KeyboardPrototype({ nav }: { nav: Nav }) {
  const { clips, update, remove } = useClips();
  const [message, setMessage] = useState("Hey! Here's the info you asked for: ");
  const [searching, setSearching] = useState(false);
  const [q, setQ] = useState("");
  const [pinnedOnly, setPinnedOnly] = useState(false);
  const [toDelete, setToDelete] = useState<Clip | null>(null);
  const list = useMemo(() => sortClips(filterClips(clips, q, pinnedOnly), "modified"), [clips, q, pinnedOnly]);

  return (
    <div className="flex min-h-full flex-col">
      <TopBar
        left={<IconBtn label="Back" onClick={() => nav({ name: "library" })}><ArrowLeft className="h-5 w-5" /></IconBtn>}
        title={<span className="text-[15px] font-semibold">Keyboard panel</span>}
      />
      <p className="mx-4 mt-3 rounded-lg border border-dashed border-border px-3 py-2 text-[12px] text-muted-foreground">
        Visual prototype only — not a real Android keyboard. The native panel is provided by ClipMaxImeService.
      </p>

      {/* Mock host app */}
      <div className="flex-1 px-4 py-3">
        <div className="text-[11px] font-medium uppercase tracking-wider text-muted-foreground">Messages · Lena</div>
        <div className="mt-2 rounded-xl border border-border bg-surface p-3 text-sm whitespace-pre-wrap min-h-24">
          {message}<span className="ml-px inline-block h-4 w-0.5 translate-y-0.5 animate-pulse bg-mint" />
        </div>
        <Btn size="sm" variant="ghost" className="mt-1" onClick={() => setMessage("")}>Clear message</Btn>
      </div>

      {/* Keyboard extension panel */}
      <div className="sticky bottom-0 border-t border-border bg-surface-2" role="region" aria-label="ClipMax keyboard panel (prototype)">
        <div className="flex h-11 items-center gap-1 px-1.5">
          {searching ? (
            <>
              <Search className="ml-2 h-4 w-4 text-muted-foreground" />
              <input autoFocus value={q} onChange={(e) => setQ(e.target.value)} placeholder="Search snippets" aria-label="Search snippets" className="h-9 min-w-0 flex-1 bg-transparent text-sm outline-none" />
              <IconBtn label="Close search" size="iconSm" onClick={() => { setSearching(false); setQ(""); }}><X className="h-4 w-4" /></IconBtn>
            </>
          ) : (
            <>
              <span className="px-2 text-[13px] font-semibold">Clip<span className="text-mint">Max</span></span>
              <span className="flex-1" />
              <IconBtn label="Search snippets" size="iconSm" onClick={() => setSearching(true)}><Search className="h-4 w-4" /></IconBtn>
              <IconBtn label={pinnedOnly ? "Show all" : "Show pinned"} size="iconSm" aria-pressed={pinnedOnly} className={cn(pinnedOnly && "bg-mint-soft text-mint-foreground")} onClick={() => setPinnedOnly((v) => !v)}><Pin className="h-4 w-4" /></IconBtn>
            </>
          )}
        </div>

        <ul className="no-scrollbar flex h-[148px] flex-col gap-1.5 overflow-y-auto px-2 pb-2">
          {list.map((c) => (
            <li key={c.id} className="flex items-center gap-1 rounded-lg border border-border bg-surface pl-3">
              <div className="min-w-0 flex-1 py-1.5">
                <div className="flex items-center gap-1 text-[13px] font-medium">
                  {c.pinned && <Pin className="h-3 w-3 shrink-0 text-mint" aria-label="Pinned" />}
                  <span className="truncate">{c.title}</span>
                </div>
                <div className="truncate text-[12px] text-muted-foreground">{c.content.replace(/\s+/g, " ")}</div>
              </div>
              <Btn size="sm" variant="mint" className="h-8 px-3" onClick={() => setMessage((m) => m + c.content)}>Insert</Btn>
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <IconBtn label={`More actions for ${c.title}`} size="iconSm"><MoreHorizontal className="h-4 w-4" /></IconBtn>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end">
                  <DropdownMenuItem onSelect={() => nav({ name: "editor", id: c.id })}><Pencil className="h-4 w-4" />Edit</DropdownMenuItem>
                  <DropdownMenuItem onSelect={() => { update(c.id, { pinned: !c.pinned }); toast(c.pinned ? "Unpinned" : "Pinned"); }}>
                    {c.pinned ? <PinOff className="h-4 w-4" /> : <Pin className="h-4 w-4" />}{c.pinned ? "Unpin" : "Pin"}
                  </DropdownMenuItem>
                  <DropdownMenuItem className="text-destructive" onSelect={() => setToDelete(c)}><Trash2 className="h-4 w-4" />Delete</DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            </li>
          ))}
          {!list.length && <li className="py-6 text-center text-[12px] text-muted-foreground">No snippets{q ? ` for “${q}”` : ""}</li>}
        </ul>

        {/* Decorative system keyboard placeholder */}
        <div aria-hidden className="space-y-1.5 border-t border-border px-1.5 py-2 opacity-70">
          {["qwertyuiop", "asdfghjkl", "zxcvbnm"].map((row, i) => (
            <div key={row} className="flex justify-center gap-1">
              {row.split("").map((k) => <span key={k} className="grid h-8 flex-1 max-w-8 place-items-center rounded bg-key text-[13px] shadow-[0_1px_0_var(--border)]">{k}</span>)}
              {i === 2 && <span className="grid h-8 w-10 place-items-center rounded bg-key"><Delete className="h-3.5 w-3.5" /></span>}
            </div>
          ))}
          <div className="flex gap-1">
            <span className="h-8 w-12 rounded bg-key" />
            <span className="h-8 flex-1 rounded bg-key" />
            <span className="grid h-8 w-12 place-items-center rounded bg-key"><CornerDownLeft className="h-3.5 w-3.5" /></span>
          </div>
        </div>
      </div>

      <Confirm open={!!toDelete} onOpenChange={(o) => !o && setToDelete(null)} title="Delete snippet?" description={`“${toDelete?.title}” will be removed.`} confirmLabel="Delete" onConfirm={() => { if (toDelete) remove(toDelete.id); setToDelete(null); toast("Snippet deleted"); }} />
    </div>
  );
}
