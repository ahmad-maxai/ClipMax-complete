import { useMemo, useState } from "react";
import { FileUp, Moon, Pin, Plus, Search, Settings, Sun, X, Keyboard } from "lucide-react";
import { toast } from "sonner";
import { Btn, IconBtn, TopBar, Wordmark } from "./primitives";
import { SORT_LABELS, bytesOf, filterClips, formatBytes, relTime, sortClips, useClips, type Clip, type SortKey } from "@/lib/clipstore";
import { cn } from "@/lib/utils";
import type { Nav } from "./types";

export function Library({ nav, dark, toggleTheme }: { nav: Nav; dark: boolean; toggleTheme: () => void }) {
  const { clips, create } = useClips();
  const [draft, setDraft] = useState("");
  const [query, setQuery] = useState("");
  const [sort, setSort] = useState<SortKey>("modified");
  const [pinnedOnly, setPinnedOnly] = useState(false);

  const visible = useMemo(() => sortClips(filterClips(clips, query, pinnedOnly), sort), [clips, query, pinnedOnly, sort]);
  const totalBytes = clips.reduce((n, c) => n + bytesOf(c.title) + bytesOf(c.content), 0);
  const pinnedCount = clips.filter((c) => c.pinned).length;

  const importTxt = () => {
    const c = create("meeting-agenda.txt", "Agenda\n- Welcome and context\n- Roadmap review\n- Open questions\n- Next steps");
    toast.success("Imported meeting-agenda.txt", { description: "Simulated — the app uses Android's document picker." });
    nav({ name: "details", id: c.id });
  };

  return (
    <div className="flex min-h-full flex-col">
      <TopBar
        title={<Wordmark />}
        right={
          <>
            <IconBtn label="Keyboard prototype" onClick={() => nav({ name: "keyboard" })}><Keyboard className="h-5 w-5" /></IconBtn>
            <IconBtn label={dark ? "Switch to light theme" : "Switch to dark theme"} onClick={toggleTheme}>
              {dark ? <Sun className="h-5 w-5" /> : <Moon className="h-5 w-5" />}
            </IconBtn>
            <IconBtn label="Settings" onClick={() => nav({ name: "settings" })}><Settings className="h-5 w-5" /></IconBtn>
          </>
        }
      />

      <div className="space-y-3 px-4 pt-3">
        <form
          className="flex gap-2"
          role="search"
          onSubmit={(e) => { e.preventDefault(); setQuery(draft); }}
        >
          <label className="relative flex-1">
            <span className="sr-only">Search title and content</span>
            <Search className="pointer-events-none absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
            <input
              value={draft}
              onChange={(e) => { setDraft(e.target.value); if (!e.target.value) setQuery(""); }}
              placeholder="Search title or content"
              className="h-11 w-full rounded-lg border border-input bg-surface pl-9 pr-9 text-sm outline-none placeholder:text-muted-foreground focus:border-mint focus:ring-2 focus:ring-ring/30"
            />
            {draft && (
              <button type="button" aria-label="Clear search" onClick={() => { setDraft(""); setQuery(""); }} className="absolute right-1 top-1/2 grid h-9 w-9 -translate-y-1/2 place-items-center rounded-md text-muted-foreground hover:bg-accent">
                <X className="h-4 w-4" />
              </button>
            )}
          </label>
          <Btn type="submit" variant="primary">Search</Btn>
        </form>

        <div className="flex items-end justify-between gap-2">
          <div>
            <h1 className="text-lg font-semibold tracking-tight">Saved items</h1>
            <p className="text-xs text-muted-foreground">
              {clips.length} items · {pinnedCount} pinned · {formatBytes(totalBytes)}
            </p>
          </div>
          <label className="relative">
            <span className="sr-only">Sort by</span>
            <select
              value={sort}
              onChange={(e) => setSort(e.target.value as SortKey)}
              className="h-9 appearance-none rounded-lg border border-input bg-surface pl-3 pr-8 text-[13px] font-medium outline-none focus:ring-2 focus:ring-ring/30"
            >
              {(Object.keys(SORT_LABELS) as SortKey[]).map((k) => <option key={k} value={k}>{SORT_LABELS[k]}</option>)}
            </select>
            <svg className="pointer-events-none absolute right-2.5 top-1/2 h-3.5 w-3.5 -translate-y-1/2 text-muted-foreground" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" aria-hidden><path d="m6 9 6 6 6-6" /></svg>
          </label>
        </div>

        <div className="flex gap-2">
          <FilterChip active={!pinnedOnly} onClick={() => setPinnedOnly(false)}>All</FilterChip>
          <FilterChip active={pinnedOnly} onClick={() => setPinnedOnly(true)}><Pin className="h-3.5 w-3.5" />Pinned</FilterChip>
          {query && <span className="ml-auto self-center text-xs text-muted-foreground">{visible.length} match{visible.length === 1 ? "" : "es"}</span>}
        </div>
      </div>

      <ul className="flex-1 space-y-2 px-4 pb-24 pt-3">
        {visible.map((c) => <li key={c.id}><ClipCard clip={c} query={query} onOpen={() => nav({ name: "details", id: c.id })} /></li>)}
        {visible.length === 0 && (
          <li className="rounded-xl border border-dashed border-border px-4 py-10 text-center text-sm text-muted-foreground">
            {clips.length === 0 ? "No saved items yet. Create one or import a .txt file." : "Nothing matches. Try a different search or filter."}
          </li>
        )}
      </ul>

      <div className="sticky bottom-0 flex gap-2 border-t border-border bg-background px-4 py-3">
        <Btn className="flex-1" onClick={importTxt}><FileUp className="h-4 w-4" />Import .txt</Btn>
        <Btn className="flex-1" variant="primary" onClick={() => nav({ name: "editor" })}><Plus className="h-4 w-4" />New item</Btn>
      </div>
    </div>
  );
}

function FilterChip({ active, children, onClick }: { active: boolean; children: React.ReactNode; onClick: () => void }) {
  return (
    <button
      type="button"
      aria-pressed={active}
      onClick={onClick}
      className={cn(
        "inline-flex h-8 items-center gap-1.5 rounded-full border px-3 text-[13px] font-medium transition-colors",
        active ? "border-mint/50 bg-mint-soft text-mint-foreground" : "border-border bg-surface text-muted-foreground hover:bg-accent",
      )}
    >
      {children}
    </button>
  );
}

function ClipCard({ clip, onOpen, query }: { clip: Clip; onOpen: () => void; query: string }) {
  const preview = clip.content.replace(/\s+/g, " ").trim();
  return (
    <button
      type="button"
      onClick={onOpen}
      className="block w-full rounded-xl border border-border bg-surface px-3.5 py-3 text-left transition-colors hover:bg-surface-2 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring"
    >
      <div className="flex items-center gap-2">
        <h3 className="min-w-0 flex-1 truncate text-[15px] font-semibold"><Highlight text={clip.title} q={query} /></h3>
        {clip.pinned && (
          <span className="inline-flex items-center gap-1 rounded-full bg-mint-soft px-2 py-0.5 text-[11px] font-medium text-mint-foreground">
            <Pin className="h-3 w-3" aria-hidden />Pinned
          </span>
        )}
      </div>
      <p className={cn("mt-1 line-clamp-2 text-[13px] leading-snug text-muted-foreground", /^git |\d{4}/.test(clip.content) && "font-mono text-[12px]")}>
        <Highlight text={preview} q={query} />
      </p>
      <div className="mt-2 flex items-center gap-2 text-[11px] text-muted-foreground">
        <span>{relTime(clip.modifiedAt)}</span>
        <span aria-hidden>·</span>
        <span className="font-mono">{clip.content.length.toLocaleString()} chars</span>
        <span aria-hidden>·</span>
        <span className="font-mono">{formatBytes(bytesOf(clip.content))}</span>
      </div>
    </button>
  );
}

function Highlight({ text, q }: { text: string; q: string }) {
  const t = q.trim();
  if (!t) return <>{text}</>;
  const i = text.toLowerCase().indexOf(t.toLowerCase());
  if (i < 0) return <>{text}</>;
  const start = Math.max(0, i - 30);
  return (
    <>
      {start > 0 && "…"}
      {text.slice(start, i)}
      <mark className="rounded-sm bg-mint-soft px-0.5 text-foreground">{text.slice(i, i + t.length)}</mark>
      {text.slice(i + t.length)}
    </>
  );
}
