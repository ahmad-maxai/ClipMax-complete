import { useState } from "react";
import { ArrowLeft, ArchiveRestore, ChevronDown, Download, Keyboard, ShieldCheck, Trash2 } from "lucide-react";
import { toast } from "sonner";
import { Switch } from "@/components/ui/switch";
import { Btn, IconBtn, Section, TopBar } from "./primitives";
import { Confirm } from "./Confirm";
import { RETENTION_LABELS, bytesOf, formatBytes, useClips, type Retention } from "@/lib/clipstore";
import { cn } from "@/lib/utils";
import type { Nav } from "./types";

export function SettingsScreen({ nav }: { nav: Nav }) {
  const { clips, retention, setRetention, capture, setCapture, removeAll, restoreSamples } = useClips();
  const [privacyOpen, setPrivacyOpen] = useState(false);
  const [confirmAll, setConfirmAll] = useState(false);
  const [confirmRestore, setConfirmRestore] = useState(false);
  const bytes = clips.reduce((n, c) => n + bytesOf(c.title) + bytesOf(c.content), 0);
  const pinned = clips.filter((c) => c.pinned).length;

  return (
    <div className="flex min-h-full flex-col">
      <TopBar
        left={<IconBtn label="Back" onClick={() => nav({ name: "library" })}><ArrowLeft className="h-5 w-5" /></IconBtn>}
        title={<span className="text-[15px] font-semibold">Settings</span>}
      />
      <div className="space-y-3 px-4 py-4">
        <Section title="Storage">
          <div className="grid grid-cols-3 divide-x divide-border px-1 py-3 text-center">
            <Stat v={String(clips.length)} k="Items" />
            <Stat v={String(pinned)} k="Pinned" />
            <Stat v={formatBytes(bytes)} k="On device" />
          </div>
        </Section>

        <Section title="Keyboard">
          <div className="flex gap-3 px-4 py-3">
            <span className="grid h-10 w-10 shrink-0 place-items-center rounded-lg bg-mint-soft text-mint-foreground"><Keyboard className="h-5 w-5" /></span>
            <div className="min-w-0 text-sm">
              <p className="font-medium">ClipMax keyboard</p>
              <ol className="mt-1 list-decimal space-y-0.5 pl-4 text-[13px] text-muted-foreground">
                <li>Enable ClipMax in system keyboard settings</li>
                <li>Switch to it from the keyboard picker</li>
              </ol>
            </div>
          </div>
          <div className="flex gap-2 px-4 pb-3">
            <Btn size="sm" className="flex-1" onClick={() => toast("Keyboard settings", { description: "Simulated — the app opens Android input method settings." })}>Enable</Btn>
            <Btn size="sm" className="flex-1" onClick={() => toast("Keyboard picker", { description: "Simulated — the app shows Android's input method picker." })}>Switch</Btn>
            <Btn size="sm" variant="subtle" className="flex-1" onClick={() => nav({ name: "keyboard" })}>Preview</Btn>
          </div>
        </Section>

        <Section title="Capture & retention">
          <label className="flex items-center gap-3 px-4 py-3">
            <span className="flex-1">
              <span className="block text-sm font-medium">Automatic capture</span>
              <span className="block text-[13px] text-muted-foreground">Save copied text while ClipMax is open</span>
            </span>
            <Switch checked={capture} onCheckedChange={(v) => { setCapture(v); toast(v ? "Automatic capture on" : "Automatic capture off"); }} aria-label="Automatic capture" />
          </label>
          <div className="border-t border-border px-4 py-3">
            <p id="ret-label" className="text-sm font-medium">Keep captured items</p>
            <p className="text-[13px] text-muted-foreground">Pinned and manually saved items are never auto-removed.</p>
            <div role="radiogroup" aria-labelledby="ret-label" className="mt-2 grid grid-cols-3 gap-1.5">
              {(Object.keys(RETENTION_LABELS) as Retention[]).map((r) => (
                <button
                  key={r}
                  type="button"
                  role="radio"
                  aria-checked={retention === r}
                  onClick={() => setRetention(r)}
                  className={cn(
                    "h-10 rounded-lg border text-[13px] font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring",
                    retention === r ? "border-mint bg-mint-soft text-mint-foreground" : "border-border bg-surface hover:bg-accent",
                  )}
                >
                  {RETENTION_LABELS[r]}
                </button>
              ))}
            </div>
          </div>
        </Section>

        <Section title="Backup">
          <div className="flex gap-2 px-4 py-3">
            <Btn size="sm" className="flex-1" onClick={() => toast.success("Backup created", { description: `clipmax-backup.zip · ${clips.length} items (simulated)` })}><Download className="h-4 w-4" />Create ZIP</Btn>
            <Btn size="sm" className="flex-1" onClick={() => setConfirmRestore(true)}><ArchiveRestore className="h-4 w-4" />Restore</Btn>
          </div>
        </Section>

        <Section>
          <button type="button" aria-expanded={privacyOpen} onClick={() => setPrivacyOpen((v) => !v)} className="flex w-full items-center gap-3 px-4 py-3 text-left">
            <ShieldCheck className="h-5 w-5 text-mint" />
            <span className="flex-1 text-sm font-medium">How ClipMax handles your data</span>
            <ChevronDown className={cn("h-4 w-4 transition-transform", privacyOpen && "rotate-180")} />
          </button>
          {privacyOpen && (
            <ul className="list-disc space-y-1.5 border-t border-border px-4 py-3 pl-8 text-[13px] leading-relaxed text-muted-foreground">
              <li>Everything is stored only in the app's private storage on this device.</li>
              <li>No accounts, no cloud sync, no analytics on your text.</li>
              <li>Backups are ZIP files you create and place yourself — treat them as sensitive.</li>
              <li>Android limits background clipboard reads; capture works while the app is in focus.</li>
              <li>Avoid storing passwords or one-time codes unless you accept the risk.</li>
            </ul>
          )}
        </Section>

        <Section title="Danger zone">
          <div className="px-4 py-3">
            <Btn variant="dangerOutline" className="w-full" onClick={() => setConfirmAll(true)} disabled={!clips.length}><Trash2 className="h-4 w-4" />Delete all saved data</Btn>
          </div>
        </Section>

        <p className="pb-2 pt-1 text-center text-[11px] text-muted-foreground">ClipMax v0.5.1 · Visual design prototype</p>
      </div>

      <Confirm open={confirmAll} onOpenChange={setConfirmAll} title="Delete all saved data?" description={`All ${clips.length} items, including pinned ones, will be permanently removed. This cannot be undone.`} confirmLabel="Delete all" onConfirm={() => { removeAll(); toast("All data deleted"); }} />
      <Confirm open={confirmRestore} onOpenChange={setConfirmRestore} destructive={false} title="Restore from backup?" description="Simulated: restores the sample library. In the app you pick a ClipMax ZIP via the document picker." confirmLabel="Restore" onConfirm={() => { restoreSamples(); toast.success("Backup restored (simulated)"); }} />
    </div>
  );
}

function Stat({ v, k }: { v: string; k: string }) {
  return (
    <div>
      <div className="text-lg font-semibold tracking-tight">{v}</div>
      <div className="text-[11px] text-muted-foreground">{k}</div>
    </div>
  );
}
