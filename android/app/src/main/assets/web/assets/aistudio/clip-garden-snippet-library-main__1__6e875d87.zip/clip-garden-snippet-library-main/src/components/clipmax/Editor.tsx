import { useRef, useState } from "react";
import { ArrowLeft, ChevronDown, ChevronUp, ClipboardPaste, FileUp, Search, X } from "lucide-react";
import { toast } from "sonner";
import { Btn, IconBtn, TopBar } from "./primitives";
import { Confirm } from "./Confirm";
import { bytesOf, formatBytes, useClips } from "@/lib/clipstore";
import type { Nav } from "./types";

export function Editor({ id, nav }: { id?: string; nav: Nav }) {
  const { get, create, update } = useClips();
  const existing = id ? get(id) : undefined;
  const [title, setTitle] = useState(existing?.title ?? "");
  const [content, setContent] = useState(existing?.content ?? "");
  const [saved, setSaved] = useState({ title: existing?.title ?? "", content: existing?.content ?? "" });
  const [currentId, setCurrentId] = useState(id);
  const [findOpen, setFindOpen] = useState(false);
  const [find, setFind] = useState("");
  const [matchIdx, setMatchIdx] = useState(0);
  const [leaving, setLeaving] = useState(false);
  const ta = useRef<HTMLTextAreaElement>(null);

  const dirty = title !== saved.title || content !== saved.content;
  const matches = find ? [...content.toLowerCase().matchAll(new RegExp(find.toLowerCase().replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), "g"))].flatMap((m) => m.index === undefined ? [] : [m.index]) : [];

  const goMatch = (dir: 1 | -1) => {
    if (!matches.length || !ta.current) return;
    const i = (matchIdx + dir + matches.length) % matches.length;
    const start = matches[i];
    if (start === undefined) return;
    setMatchIdx(i);
    ta.current.focus();
    ta.current.setSelectionRange(start, start + find.length);
  };

  const insert = (text: string) => {
    const el = ta.current;
    const s = el?.selectionStart ?? content.length;
    const e = el?.selectionEnd ?? content.length;
    setContent(content.slice(0, s) + text + content.slice(e));
  };

  const save = () => {
    if (!content.trim() && !title.trim()) {
      toast.error("Nothing to save yet");
      return;
    }
    if (currentId) update(currentId, { title: title.trim() || "Untitled", content });
    else setCurrentId(create(title, content).id);
    setSaved({ title, content });
    toast.success("Saved");
  };

  const back = () => (dirty ? setLeaving(true) : nav(currentId ? { name: "details", id: currentId } : { name: "library" }));

  return (
    <div className="flex h-full min-h-full flex-col">
      <TopBar
        left={<IconBtn label="Back" onClick={back}><ArrowLeft className="h-5 w-5" /></IconBtn>}
        title={
          <div className="flex items-center gap-2">
            <span className="text-[15px] font-semibold">{existing ? "Edit item" : "New item"}</span>
            {dirty && <span className="rounded-full bg-mint-soft px-2 py-0.5 text-[11px] font-medium text-mint-foreground">Unsaved</span>}
          </div>
        }
        right={<Btn variant="primary" size="sm" onClick={save} disabled={!dirty}>Save</Btn>}
      />

      <div className="flex gap-1 border-b border-border px-2 py-1.5">
        <Btn variant="ghost" size="sm" onClick={() => { insert("Simulated clipboard text"); toast("Pasted sample text", { description: "Simulated — the app reads Android's clipboard." }); }}>
          <ClipboardPaste className="h-4 w-4" />Paste
        </Btn>
        <Btn variant="ghost" size="sm" aria-pressed={findOpen} onClick={() => setFindOpen((v) => !v)}><Search className="h-4 w-4" />Find</Btn>
        <Btn variant="ghost" size="sm" onClick={() => { insert("Imported from notes.txt\nLine two of the sample file."); toast("Imported notes.txt", { description: "Simulated — the app uses Android's document picker." }); }}>
          <FileUp className="h-4 w-4" />Import .txt
        </Btn>
      </div>

      {findOpen && (
        <div className="flex items-center gap-1 border-b border-border bg-surface-2 px-2 py-1.5">
          <input
            autoFocus
            aria-label="Find in content"
            value={find}
            onChange={(e) => { setFind(e.target.value); setMatchIdx(-1); }}
            onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), goMatch(1))}
            placeholder="Find in content"
            className="h-9 min-w-0 flex-1 rounded-md border border-input bg-surface px-2.5 text-sm outline-none focus:border-mint"
          />
          <span className="w-14 text-center font-mono text-[11px] text-muted-foreground" aria-live="polite">
            {find ? `${matches.length ? Math.max(matchIdx, 0) + 1 : 0}/${matches.length}` : ""}
          </span>
          <IconBtn label="Previous match" size="iconSm" onClick={() => goMatch(-1)} disabled={!matches.length}><ChevronUp className="h-4 w-4" /></IconBtn>
          <IconBtn label="Next match" size="iconSm" onClick={() => goMatch(1)} disabled={!matches.length}><ChevronDown className="h-4 w-4" /></IconBtn>
          <IconBtn label="Close find" size="iconSm" onClick={() => { setFindOpen(false); setFind(""); }}><X className="h-4 w-4" /></IconBtn>
        </div>
      )}

      <div className="flex flex-1 flex-col gap-2 px-4 pt-3">
        <label className="sr-only" htmlFor="ed-title">Title</label>
        <input id="ed-title" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Title" className="h-11 w-full border-b border-border bg-transparent text-lg font-semibold outline-none placeholder:text-muted-foreground focus:border-mint" />
        <label className="sr-only" htmlFor="ed-content">Content</label>
        <textarea ref={ta} id="ed-content" value={content} onChange={(e) => setContent(e.target.value)} placeholder="Type or paste text…" className="min-h-[300px] w-full flex-1 resize-none bg-transparent text-[15px] leading-relaxed outline-none placeholder:text-muted-foreground" />
      </div>

      <div className="sticky bottom-0 flex items-center justify-between border-t border-border bg-background px-4 py-2 font-mono text-[11px] text-muted-foreground" aria-live="polite">
        <span>{content.length.toLocaleString()} characters</span>
        <span>{formatBytes(bytesOf(content))}</span>
      </div>

      <Confirm
        open={leaving}
        onOpenChange={setLeaving}
        title="Discard changes?"
        description="You have unsaved edits. Leaving now will discard them."
        confirmLabel="Discard"
        onConfirm={() => nav(currentId ? { name: "details", id: currentId } : { name: "library" })}
      />
    </div>
  );
}
