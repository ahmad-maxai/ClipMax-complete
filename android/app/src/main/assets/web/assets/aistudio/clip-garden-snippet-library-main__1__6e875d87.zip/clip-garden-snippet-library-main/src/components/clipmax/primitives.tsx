import { cva, type VariantProps } from "class-variance-authority";
import type { ButtonHTMLAttributes, ReactNode } from "react";
import { cn } from "@/lib/utils";

export const btn = cva(
  "inline-flex items-center justify-center gap-2 rounded-lg text-sm font-medium transition-colors focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring disabled:opacity-40 disabled:pointer-events-none select-none",
  {
    variants: {
      variant: {
        primary: "bg-primary text-primary-foreground hover:opacity-90",
        mint: "bg-mint text-primary-foreground hover:opacity-90 dark:text-background",
        outline: "border border-border bg-surface text-foreground hover:bg-accent",
        ghost: "text-foreground hover:bg-accent",
        subtle: "bg-secondary text-secondary-foreground hover:bg-accent",
        danger: "bg-destructive text-destructive-foreground hover:opacity-90",
        dangerOutline: "border border-destructive/40 text-destructive hover:bg-destructive/10",
      },
      size: {
        md: "h-11 px-4",
        sm: "h-9 px-3 text-[13px]",
        icon: "h-11 w-11",
        iconSm: "h-9 w-9",
      },
    },
    defaultVariants: { variant: "outline", size: "md" },
  },
);

type BtnProps = ButtonHTMLAttributes<HTMLButtonElement> & VariantProps<typeof btn>;
export function Btn({ className, variant, size, ...p }: BtnProps) {
  return <button type="button" className={cn(btn({ variant, size }), className)} {...p} />;
}

export function IconBtn({ label, className, variant = "ghost", size = "icon", ...p }: BtnProps & { label: string }) {
  return <Btn aria-label={label} title={label} variant={variant} size={size} className={className} {...p} />;
}

export function TopBar({ left, title, right }: { left?: ReactNode; title: ReactNode; right?: ReactNode }) {
  return (
    <header className="sticky top-0 z-10 flex h-14 items-center gap-1 border-b border-border bg-background/95 px-2 backdrop-blur-none">
      {left}
      <div className="min-w-0 flex-1 px-1">{title}</div>
      <div className="flex items-center">{right}</div>
    </header>
  );
}

export function Section({ title, children, className }: { title?: string; children: ReactNode; className?: string }) {
  return (
    <section className={cn("rounded-xl border border-border bg-surface", className)}>
      {title && <h2 className="px-4 pt-3 text-[11px] font-semibold uppercase tracking-[0.08em] text-muted-foreground">{title}</h2>}
      {children}
    </section>
  );
}

export function Wordmark() {
  return (
    <div className="flex items-center gap-2">
      <span className="grid h-7 w-7 place-items-center rounded-md bg-primary text-primary-foreground">
        <svg viewBox="0 0 24 24" className="h-4 w-4" fill="none" stroke="currentColor" strokeWidth="2.2" strokeLinecap="round" aria-hidden>
          <rect x="6" y="4" width="12" height="16" rx="2" />
          <path d="M9 9h6M9 13h4" />
        </svg>
      </span>
      <span className="text-[17px] font-semibold tracking-tight">
        Clip<span className="text-mint">Max</span>
      </span>
    </div>
  );
}
