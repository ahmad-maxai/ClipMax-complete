// Prototype-only, in-memory stand-in for the native Kotlin ClipStore.
// Nothing here touches Android storage, the system clipboard, or the IME.
import { createContext, useContext, useState, type ReactNode } from "react";

export type Clip = {
  id: string;
  title: string;
  content: string;
  pinned: boolean;
  createdAt: number;
  modifiedAt: number;
};

export type SortKey = "modified" | "newest" | "oldest" | "title";
export type Retention = "off" | "1h" | "6h" | "24h" | "72h" | "forever";

export const SORT_LABELS: Record<SortKey, string> = {
  modified: "Recently modified",
  newest: "Newest first",
  oldest: "Oldest first",
  title: "Title A–Z",
};

export const RETENTION_LABELS: Record<Retention, string> = {
  off: "Off",
  "1h": "1 hour",
  "6h": "6 hours",
  "24h": "24 hours",
  "72h": "72 hours",
  forever: "Forever",
};

const H = 3600_000;
const now = Date.now();

const LONG = `Meeting notes — Q4 platform review

1. Release cadence
We agreed to move from a six-week to a four-week release train for the Android client. Feature flags remain the default mechanism for anything that is not ready; nothing half-finished should block a train.

2. Storage
Local storage stays the source of truth. Backups are user-initiated ZIP archives only. No silent sync, no analytics on clip contents, ever.

3. Keyboard extension
The keyboard panel should stay compact: search, pinned access, and a short list of snippets. Insert is the primary action; Edit, Pin and Delete live under More.

4. Accessibility
Minimum 48dp touch targets. All icon buttons need content descriptions. Respect system font scaling up to 200% without clipping.

5. Open questions
- Should retention apply to pinned items? (Current answer: no, pinned items are kept.)
- Do we expose byte size, or only characters? (Both, in the details view.)

Action items: Ahmad to draft the retention copy, Lena to audit contrast in dark mode, Tom to profile cold start on low-end devices.`;

const SAMPLE: Clip[] = [
  { id: "c1", title: "Home address", content: "Plot 14, Ahmadu Bello Way\nKaduna 800283\nNigeria", pinned: true, createdAt: now - 400 * H, modifiedAt: now - 30 * H },
  { id: "c2", title: "Support reply — refund", content: "Hi there, thanks for reaching out. I've processed your refund and you should see it on your statement within 3–5 business days. Let me know if there's anything else I can help with.", pinned: true, createdAt: now - 200 * H, modifiedAt: now - 2 * H },
  { id: "c3", title: "Q4 platform review notes", content: LONG, pinned: false, createdAt: now - 72 * H, modifiedAt: now - 0.4 * H },
  { id: "c4", title: "Wi‑Fi guest password", content: "Network: Studio-Guest\nPassword: olive-harbor-2731", pinned: false, createdAt: now - 20 * H, modifiedAt: now - 20 * H },
  { id: "c5", title: "Git: undo last commit", content: "git reset --soft HEAD~1", pinned: false, createdAt: now - 140 * H, modifiedAt: now - 90 * H },
  { id: "c6", title: "Email signature", content: "Ahmad Said Tanko\nProduct Engineer · ClipMax\n+234 800 000 0000", pinned: false, createdAt: now - 600 * H, modifiedAt: now - 300 * H },
  { id: "c7", title: "Tracking number", content: "1Z 999 AA1 01 2345 6784", pinned: false, createdAt: now - 5 * H, modifiedAt: now - 5 * H },
];

export const bytesOf = (s: string) => new TextEncoder().encode(s).length;

export function formatBytes(n: number) {
  if (n < 1024) return `${n} B`;
  if (n < 1024 * 1024) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / 1024 / 1024).toFixed(2)} MB`;
}

export function relTime(t: number) {
  const d = Date.now() - t;
  const m = Math.round(d / 60000);
  if (m < 1) return "Just now";
  if (m < 60) return `${m} min ago`;
  const h = Math.round(m / 60);
  if (h < 24) return `${h} h ago`;
  const days = Math.round(h / 24);
  if (days < 7) return `${days} d ago`;
  return new Date(t).toLocaleDateString(undefined, { month: "short", day: "numeric" });
}

export function fullDate(t: number) {
  return new Date(t).toLocaleString(undefined, { dateStyle: "medium", timeStyle: "short" });
}

export function sortClips(list: Clip[], sort: SortKey) {
  const s = [...list];
  s.sort((a, b) => {
    if (a.pinned !== b.pinned) return a.pinned ? -1 : 1;
    switch (sort) {
      case "modified": return b.modifiedAt - a.modifiedAt;
      case "newest": return b.createdAt - a.createdAt;
      case "oldest": return a.createdAt - b.createdAt;
      case "title": return a.title.localeCompare(b.title);
    }
  });
  return s;
}

export function filterClips(list: Clip[], q: string, pinnedOnly: boolean) {
  const t = q.trim().toLowerCase();
  return list.filter(
    (c) => (!pinnedOnly || c.pinned) && (!t || c.title.toLowerCase().includes(t) || c.content.toLowerCase().includes(t)),
  );
}

type Store = {
  clips: Clip[];
  get: (id: string) => Clip | undefined;
  create: (title: string, content: string) => Clip;
  update: (id: string, patch: Partial<Pick<Clip, "title" | "content" | "pinned">>) => void;
  duplicate: (id: string) => Clip | undefined;
  remove: (id: string) => void;
  removeAll: () => void;
  restoreSamples: () => void;
  retention: Retention;
  setRetention: (r: Retention) => void;
  capture: boolean;
  setCapture: (b: boolean) => void;
};

const Ctx = createContext<Store | null>(null);
let seq = 100;

export function ClipStoreProvider({ children }: { children: ReactNode }) {
  const [clips, setClips] = useState<Clip[]>(SAMPLE);
  const [retention, setRetention] = useState<Retention>("24h");
  const [capture, setCapture] = useState(false);

  const store: Store = {
    clips,
    get: (id) => clips.find((c) => c.id === id),
    create: (title, content) => {
      const t = Date.now();
      const c: Clip = { id: `n${seq++}`, title: title.trim() || "Untitled", content, pinned: false, createdAt: t, modifiedAt: t };
      setClips((p) => [c, ...p]);
      return c;
    },
    update: (id, patch) =>
      setClips((p) => p.map((c) => (c.id === id ? { ...c, ...patch, modifiedAt: "pinned" in patch && Object.keys(patch).length === 1 ? c.modifiedAt : Date.now() } : c))),
    duplicate: (id) => {
      const src = clips.find((c) => c.id === id);
      if (!src) return;
      const t = Date.now();
      const c: Clip = { ...src, id: `n${seq++}`, title: `${src.title} (copy)`, pinned: false, createdAt: t, modifiedAt: t };
      setClips((p) => [c, ...p]);
      return c;
    },
    remove: (id) => setClips((p) => p.filter((c) => c.id !== id)),
    removeAll: () => setClips([]),
    restoreSamples: () => setClips(SAMPLE),
    retention,
    setRetention,
    capture,
    setCapture,
  };
  return <Ctx.Provider value={store}>{children}</Ctx.Provider>;
}

export function useClips() {
  const s = useContext(Ctx);
  if (!s) throw new Error("useClips outside provider");
  return s;
}
