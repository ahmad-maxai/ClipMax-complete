export type Screen =
  | { name: "library" }
  | { name: "details"; id: string }
  | { name: "editor"; id?: string }
  | { name: "settings" }
  | { name: "keyboard" };

export type Nav = (s: Screen) => void;
